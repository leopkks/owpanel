import configparser
from django.contrib.auth import authenticate
from django.http import JsonResponse
from functools import wraps
import os
from django.conf import settings
from users.function import *
# Function to read api_status from the conf.ini file

def get_api_status():
    config = configparser.ConfigParser()

    # Construct the path to conf.ini using settings.BASE_DIR
    django_root = settings.BASE_DIR
    file_path = os.path.join(django_root, 'etc', 'conf.ini')

    # Check if the file exists
    if os.path.exists(file_path):
        try:
            config.read(file_path)

            # Attempt to read the 'api_status' from the config file
            # If the section or option doesn't exist, it will raise an exception
            api_status = config.get('settings', 'api_status', fallback=None)

            if api_status is not None:
                return int(api_status)  # Ensure it's an integer and return
            else:
                return 0  # If the api_status is missing, return 0

        except (configparser.NoOptionError, configparser.NoSectionError) as e:
            # If there is an error reading the section or option, return default value 0
            return 0
    else:
        # If the file doesn't exist, return 0
        return 0
    
def api_login_required(view_func):
    @wraps(view_func)
    def _wrapped_view(request, *args, **kwargs):
        # Check if API is enabled (api_status == 1)
        if get_api_status() != 1:
            return JsonResponse({'error': 'API is currently disabled'}, status=403)

        if request.method != 'POST':
            return JsonResponse({'error': 'POST method required'}, status=405)

        username = request.headers.get('username')
        password = decode(request.headers.get('apikey'))

        if not username or not password:
            return JsonResponse({'error': 'Username and password required'}, status=400)

        user = authenticate(username=username, password=password)

        if user is None:
            return JsonResponse({'error': 'Invalid credentials'}, status=401)

        request.user = user  # Attach the user manually
        return view_func(request, *args, **kwargs)

    return _wrapped_view
