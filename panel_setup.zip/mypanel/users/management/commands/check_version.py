import os
import requests
from django.core.management.base import BaseCommand
from django.conf import settings

class Command(BaseCommand):
    help = "Checks if the Django project version is up to date and creates an update file if needed"

    def handle(self, *args, **kwargs):
        try:
            # URL of the version file on the web
            version_url = "https://olspanel.com/version.txt"
            
            # Get OS details from settings, with defaults
            os_name = getattr(settings, "MY_OS_NAME", "linux")
            os_version = getattr(settings, "MY_OS_VERSION", "0")
            panel_version = getattr(settings, "VERSION", "0")
            
            # Data to send in the POST request
            data = {
                "osname": os_name,
                "osversion": os_version,
                "panel": panel_version
            }

            # Fetch the latest version
            response = requests.post(version_url, data=data, timeout=10)
            response.raise_for_status()  # Raise error if request fails
            latest_version = response.text.strip()

            # Get the current version from settings.py
            current_version = getattr(settings, "VERSION", "0.0.0")

            # Django root directory
            django_root = settings.BASE_DIR

            # Path to the update file
            update_file_path = os.path.join(django_root, 'etc', 'update')

            # Compare versions
            if current_version == latest_version:
                self.stdout.write(f"✅ The project is up to date (Version: {current_version})")
                # Remove update file if it exists (no update needed)
                if os.path.exists(update_file_path):
                    os.remove(update_file_path)
                    self.stdout.write("🗑️ Removed outdated update file.")
            else:
                self.stdout.write(f"⚠️ Update available! Current: {current_version}, Latest: {latest_version}")
                # Create the update file
                os.makedirs(os.path.dirname(update_file_path), exist_ok=True)
                with open(update_file_path, "w") as update_file:
                    update_file.write(f"{latest_version}\n")
                self.stdout.write(f"📂 Update file created at: {update_file_path}")

        except requests.RequestException as e:
            self.stderr.write(f"❌ Error fetching version info: {e}")
